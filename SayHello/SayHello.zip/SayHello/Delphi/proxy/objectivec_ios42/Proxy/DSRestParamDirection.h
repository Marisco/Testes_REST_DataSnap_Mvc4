//*******************************************************
//
//               Delphi DataSnap Framework
//
// Copyright(c) 1995-2011 Embarcadero Technologies, Inc.
//
//*******************************************************

/**
 *@brief The direction of parameters.
 */

typedef enum  {
	Unknown = 0,Input= 1, Output=2, InputOutput=3, ReturnValue=4
} DSRESTParamDirection;

